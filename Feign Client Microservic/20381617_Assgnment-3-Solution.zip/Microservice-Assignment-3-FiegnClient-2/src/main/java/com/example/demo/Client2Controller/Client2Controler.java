package com.example.demo.Client2Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Client2Entity.Client2Entity;

@RestController
public class Client2Controler {
	
	@Autowired
	private FeignClient_2_Interface feignclient;
	
	@PostMapping("/insert-customer")
	public void insertCustomers(Client2Entity cliententity,
			@RequestParam("custId") int custId,
			@RequestParam("custName") String custName,
			@RequestParam("custaddress") String custaddress) {
		cliententity.setCustomerId(custId);
		cliententity.setCustomerName(custName);
		cliententity.setCustomerAddress(custaddress);
		feignclient.insertCustomers(cliententity);
		}
	
	@GetMapping("displayAllCustomers")
	public List<Client2Entity> displayAllCustomers() {
		return feignclient.allCust();
	}
	
	@GetMapping("display/{custId}")
	public List<Client2Entity> displayone(@PathVariable("custId") int custId) {
		return feignclient.oneCust(custId);
	}
	
	@PutMapping("/update/{custId}")
	public void updateCustomers(Client2Entity cliententity,
			@RequestParam("custId") int custId,
			@RequestParam("custName") String custName,
			@RequestParam("custaddress") String custaddress) {
		cliententity.setCustomerId(custId);
		cliententity.setCustomerName(custName);
		cliententity.setCustomerAddress(custaddress);
		feignclient.update(custId, cliententity);
		}
	
	@DeleteMapping("delete/{custId}")
	public void delete(@PathVariable("custId") int custId) {
		feignclient.delete(custId);
	}
	
	@GetMapping("Costomer-Analysis")
	public String Costomeranalysis() {
		return feignclient.printstr();
	}
	
	@GetMapping("env")
	public String custenvironment() {
		return feignclient.custenvironment();
	}
}
