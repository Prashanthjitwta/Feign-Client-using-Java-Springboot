package com.example.demo.Client2Entity;

public class Client2Entity {
	
	private String customerName;
	private int customerId;
	private String customerAddress;
	
	public Client2Entity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Client2Entity(String customerName, int customerId, String customerAddress) {
		super();
		this.customerName = customerName;
		this.customerId = customerId;
		this.customerAddress = customerAddress;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
}
