package com.example.demo.Client2Controller;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Client2Entity.Client2Entity;

@FeignClient(value = "Customer-Service")
public interface FeignClient_2_Interface {
	
	@PostMapping("/insert-customer")
	public void insertCustomers(@RequestBody Client2Entity cliententity);
	
	@GetMapping("/displayAllCustomer")
	public List<Client2Entity> allCust(); 
	
	@GetMapping("/display/{custId}")
	public List<Client2Entity> oneCust(@PathVariable("custId") int custId);
	
	@PutMapping("/update/{custId}")
	public void update(@PathVariable("custId") int custId, @RequestBody Client2Entity cliententity);
	
	@DeleteMapping("/delete/{custId}")
	public void delete(@PathVariable("custId") int custId);
	
	@GetMapping("Costomer-Analysis")
	public String printstr();

	@GetMapping("env")
	public String custenvironment();

}
