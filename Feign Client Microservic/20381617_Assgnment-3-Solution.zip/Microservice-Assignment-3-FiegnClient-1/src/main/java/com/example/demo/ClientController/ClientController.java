package com.example.demo.ClientController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.example.demo.ClientEntity.ClientEntity;

@RestController
public class ClientController {
	
	@Autowired
	private FeignClient1Interface feignclient;
	
	@PostMapping("/insert-product")
	public void insertProducts(ClientEntity cliententity,
			@RequestParam("prodId") int prodId,
			@RequestParam("prodName") String prodName,
			@RequestParam("prodCategory") String prodCategory) {
		cliententity.setProductId(prodId);
		cliententity.setProductName(prodName);
		cliententity.setProductCategory(prodCategory);
		feignclient.insertProducts(cliententity);
		}
	
	@GetMapping("displayAllProducts")
	public List<ClientEntity> displayAllProducts() {
		return feignclient.allProd();
	}
	
	@GetMapping("display/{prodId}")
	public List<ClientEntity> displayone(@PathVariable("prodId") int prodId) {
		return feignclient.oneProd(prodId);
	}
	
	@PutMapping("/update/{prodId}")
	public void updateProducts(ClientEntity cliententity,
			@RequestParam("prodId") int prodId,
			@RequestParam("prodName") String prodName,
			@RequestParam("prodCategory") String prodCategory) {
		cliententity.setProductId(prodId);
		cliententity.setProductName(prodName);
		cliententity.setProductCategory(prodCategory);
		feignclient.update(prodId,cliententity);
		}
	
	@DeleteMapping("delete/{prodId}")
	public void delete(@PathVariable("prodId") int prodId) {
		feignclient.delete(prodId);
	}
	
	@GetMapping("inventry-details")
	public String inventrydetails() {
		return feignclient.printstr();
	}
	
	@GetMapping("env")
	public String prodenvironment() {
		return feignclient.prodenvironment();
	}
}
