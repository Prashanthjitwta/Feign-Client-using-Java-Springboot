package com.example.demo.ClientController;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.ClientEntity.ClientEntity;

@FeignClient(value = "Product-Service")
public interface FeignClient1Interface {
	
	@PostMapping("/insert-product")
	public void insertProducts(@RequestBody ClientEntity cliententity);
	
	@GetMapping("/displayAllProducts")
	public List<ClientEntity> allProd();
	
	@GetMapping("/display/{prodId}")
	public List<ClientEntity> oneProd(@PathVariable("prodId") int prodId);
	
	@PutMapping("/update/{prodId}")
	public void update(@PathVariable("prodId") int prodId,@RequestBody ClientEntity cliententity);
	
	@DeleteMapping("/delete/{prodId}")
	public void delete(@PathVariable("prodId") int prodId);
	 
	@GetMapping("inventry-details")
	public String printstr();

	@GetMapping("env")
	public String prodenvironment();
}
