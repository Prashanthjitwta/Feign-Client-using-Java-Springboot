package com.example.demo.CustService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.demo.CustEntity.CustomerEntity;

@Service
public class CustomerService {
	
	@Value("${Customer-Rating}")
	public String CustomerRating;
	@Value("${Number-Of-Customers}")
	public String NumberOfCustomers;
	@Value("${Min-Customer-Purchase}")
	public String MinCustomerPurchase;
	@Value("${Payment-Method}")
	public String PaymentMethod;
	@Value("${Description}")
	public String Description;
	
	List<CustomerEntity> li = new ArrayList<CustomerEntity>();
	HashMap<Integer,CustomerEntity> map = new HashMap<Integer,CustomerEntity>();
	
	public void saveNewRequest(CustomerEntity custentity) {
		map.put(custentity.getCustomerId(),new CustomerEntity(custentity.getCustomerName(),custentity.getCustomerId(),custentity.getCustomerAddress()));
	}

	public List<CustomerEntity> displayall() {
	//	map.forEach((k, v)-> System.out.println((v.getEmpId()+" "+v.getEmpName()+" "+v.getEmpEmail()+" "+v.getLocation())));
		Collection<CustomerEntity> values = map.values(); 		         
		ArrayList<CustomerEntity> listOfValues = new ArrayList<CustomerEntity>(values);
		return listOfValues;
	}

	public List<CustomerEntity> displaybyid(int custId) {
		li.clear();
		li.add(map.get(custId));
		return li;
	}
	
	public List<CustomerEntity> updatebyid(CustomerEntity custentity) {
		map.replace(custentity.getCustomerId(),new CustomerEntity(custentity.getCustomerName(),custentity.getCustomerId(),custentity.getCustomerAddress()));
		return li;
	}
	
	public void deletebyid(int custId) {
		map.remove(custId);
	}


}
