package com.example.demo.CustEntity;

public class CustomerEntity {
	
	private String customerName;
	private int customerId;
	private String customerAddress;
	
	public CustomerEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CustomerEntity(String customerName, int customerId, String customerAddress) {
		super();
		this.customerName = customerName;
		this.customerId = customerId;
		this.customerAddress = customerAddress;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

}
